000Stryke000 2024

Tool is used for educational purpose only. We do not force or encourage you to use 
this tool for Illegal reasons, nor use it to create a larger network.

When using our tool remember to give credits or "Hail Stryke".

Notes to be cautious :

Do not be scared on anyone in cord, they cannot do sh!t without you clicking links, downloading, etc.

--------------------------------------Hail-Hydra---------------------------------------------



Version 1.1 (Brand Public)


